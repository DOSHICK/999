chrome.action.onClicked.addListener(() => {
  chrome.system.display.getInfo(displays => {
    const primary = displays.find(d => d.isPrimary);
    const { left, top, width } = primary.workArea;

    chrome.windows.create({
      url: chrome.runtime.getURL("index.html"),
      type: "popup",
      width: 400,
      height: 600,
      top: top,
      left: left + width - 400
    });
  });
});
